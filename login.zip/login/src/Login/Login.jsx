import React, { Component } from "react";
import "./Login.css";
import { connect } from "react-redux";
import data from "./EmployeeData.json";
let result = sessionStorage.getItem("result");
// import EmployeeData from "../EmployeeDetails/EmployeeData";
// const data = require("../EmployeeDetails/EmployeeData.json");
class Login extends Component {
  constructor(props) {
    super(props);
    this.state = { email: "", password: "" };
  }
  render() {
    return (
      <div>
        {result <= 1 ? (
          <div className="login-box">
            <h1>Login</h1>
            <div className="text-box" id="text-box1">
              <i className="fa fa-user fa-lg"></i>
              <input
                name="email"
                type="text"
                placeholder="Username"
                id="email"
                onChange={e => {
                  this.setState({ email: e.target.value });
                }}
              />
            </div>
            <div id="err-email"></div>
            <div className="text-box" id="text-box2">
              <i className="fa fa-lock fa-lg"></i>
              <input
                name="password"
                type="password"
                placeholder="password"
                id="password"
                onChange={e => {
                  this.setState({ password: e.target.value });
                }}
              />
            </div>
            {this.props.result === 1 ? (
              <p style={{ color: "red" }}>Invalid Credentials</p>
            ) : null}
            <br />
            <button
              id="btn"
              type="submit"
              onClick={e => {
                this.props.fun1(this.state.email, this.state.password);
              }}
            >
              login
            </button>

            <br />
          </div>
        ) : (
          <div>
            <button
              id="logout"
              onClick={e => {
                sessionStorage.clear();
                window.location.reload(false);
              }}
            >
              logout
            </button>
            <table className="table">
              <thead id="thead">
                <th>Id</th>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Phone Number</th>
              </thead>
              <tbody id="tbody">
                {data.user.map(e => {
                  return (
                    <tr id="row">
                      <td>{e.id}</td>
                      <td>{e.name}</td>
                      <td>{e.age}</td>
                      <td>{e.gender}</td>
                      <td>{e.email}</td>
                      <td>{e.phoneNo}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    var1: state.a,
    var2: state.b,
    result: state.result
  };
};
const mapDispachToProps = dispach => {
  return {
    fun1: (a, b) => dispach({ type: "login", first: a, second: b })
    // fun2: () => dispach({ type: "fun2" })
  };
};

export default connect(mapStateToProps, mapDispachToProps)(Login);
