const initialState = {
  // a: 0,
  // b: 0,
  result: 0
};
var data = require("../Login.json");
const reducer = (state = initialState, action) => {
  const newState = { ...state };

  if (action.type === "login") {
    var result = 0;
    // console.log("hello" + action.type);
    // console.log(data.username + action.a);
    if (action.first === data.username && action.second === data.password) {
      result = 2;
      sessionStorage.setItem("result", result);
      window.location.reload(false);
    } else {
      result = 1;
    }
    newState.result = result;
  }

  return newState;
};
export default reducer;
