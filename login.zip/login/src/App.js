import React from "react";
import logo from "./logo.svg";
import {
  HashRouter as Router,
  Switch,
  Route,
  Redirect
} from "react-router-dom";
import "./App.css";
// import EmployeeData from "../src/EmployeeDetails/EmployeeData";
import Login from "../src/Login/Login";

function App() {
  return <div>hello</div>;
}

export default App;
